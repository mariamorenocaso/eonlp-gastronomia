# Pasos para la entrega (borrar este fichero antes de subir)

## 1. Crear el repositorio (las tres)

1. Crear un repositorio **público** en GitHub y añadir a las otras dos como colaboradoras.
2. Sustituir `USUARIO/REPOSITORIO` por los valores reales en:
   - `README.md`
   - `docs/index.md`
   - `mkdocs.yml` (`repo_url`)
   - `notebooks/clasificacion_gastronomia.ipynb` (primera celda de código: `GITHUB_USUARIO` y `GITHUB_REPO`)

## 2. Subir el trabajo con commits y Pull Requests (opción de arquitectura: hasta +2 puntos en v2)

La rúbrica valora los commits significativos, las PR y la contribución equilibrada. Repartid las piezas y que cada una
**suba la suya en su propia rama con una Pull Request** que revise otra compañera. Por ejemplo:

| Rama | Contenido | Quién |
|---|---|---|
| `feature/tokenizador` | `src/eonlp/tokenizer.py`, `tests/test_tokenizer.py` | ... |
| `feature/lexico-stopwords` | `src/eonlp/lexicon.py` | ... |
| `feature/morfologia` | `src/eonlp/morphology.py`, `src/eonlp/derivation.py`, `tests/test_morphology.py` | ... |
| `feature/doc-token` | `src/eonlp/tokens.py`, `src/eonlp/language.py`, `tests/test_language.py` | ... |
| `feature/dataset` | `scripts/`, `config/`, `tests/test_build_dataset.py`, `data/` | ... |
| `feature/docs-ci` | `docs/`, `mkdocs.yml`, `.readthedocs.yaml`, `.github/` | ... |
| `feature/cuaderno` | `notebooks/` | ... |

Cada una tiene que entender a fondo lo que sube: en la defensa os pueden pedir que lo expliquéis o lo modifiquéis.

## 3. Generar el dataset (requiere conexión)

```bash
pip install -e ".[dataset]"
python scripts/build_dataset.py --config config/gastronomio.json --out data
```

- Revisad la salida: si alguna clase tiene menos de 300 párrafos, subid `max_articles_per_class` en el JSON o añadid categorías.
- Categorías revisadas: corregidas `Pladoj` -> categorías gastronómicas existentes, `Deserto` -> `Desertoj` y `Alkoholaj trinkaĵoj` -> `Alkoholaĵoj`. El script complementa con artículos de respaldo reales cuando encuentra pocos candidatos.
  La categoría general se llama `Manĝaĵoj kaj trinkaĵoj`, por si os sirve para encontrar subcategorías.
- Subid a `data/` estos ficheros: `dataset.csv`, `dataset_meta.csv`, `articles.json` y `noise_report.json`.

## 4. Crear la etiqueta de versión

```bash
git tag v1.0.0
git push origin v1.0.0
```

El cuaderno instala la librería y descarga el dataset de esa etiqueta, así los resultados son reproducibles.
Si cambiáis algo después, cread `v1.0.1` y actualizad `VERSION` en el cuaderno.

## 5. Arquitectura de software (hasta +2.0 puntos en total, no por subapartado)

- **GitHub Actions:** ya funciona al hacer push (pestaña *Actions*).
- **Read the Docs:** entrar en readthedocs.org con GitHub → *Import a project* → elegir el repositorio. La configuración ya está en `.readthedocs.yaml`.
  Poned el enlace en el README.

## 6. Ejecutar el cuaderno en Colab y entregar

1. Abrir `notebooks/clasificacion_gastronomia.ipynb` en Colab → *Entorno de ejecución* → *Ejecutar todo*.
2. Comprobad la sección 11: si `Kuirlibro (Vikilibroj)` no carga, cambiadlo por otra web en Esperanto que no sea Wikipedia,
   o ponedla en `URL_PERSONALIZADA`.
3. Releed las conclusiones con los números reales.
4. **IMPORTANTE:** Si ninguna URL real carga, la demostración local de la sección 11 **no** cumple la clasificación de webs reales. Repetid la prueba con conexión antes de entregar.
5. Descargad el .ipynb **con las salidas REALES** y entregadlo.

## 7. Qué se ha verificado en esta versión

- El código de la librería y el script se comprueban con tests automáticos y datos simulados; el dataset de Vikipedio debe generarse en un entorno con acceso real a Wikipedia.
- En esta revisión se han contrastado las categorías en páginas públicas de Vikipedio (noviembre 2026), pero no la ejecución del API desde Colab.
- Si falla la etiqueta de versión, la instalación del cuaderno se detendrá (intencionadamente): no sustituye silenciosamente la librería versionada por la rama main.
- Después de publicar el repositorio, crear la etiqueta solo tras subir los CSV reales. No entregar el ZIP de trabajo como si contuviera un dataset real.
